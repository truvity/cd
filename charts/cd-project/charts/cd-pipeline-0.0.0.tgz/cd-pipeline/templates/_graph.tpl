{{/*
A project whose Stages are derived from `stageOrder` and the promotion graph
(`graph`), as the project map `cd-pipeline.project` renders, in YAML for
`fromYaml`. A project with no `stageOrder` is returned unchanged by the caller
and never comes here. Call with (dict "root" . "p" <project map>).

The rules, for each Stage of `stageOrder`, in that order:

- upstream: the first of its candidates (the project's `upstreams` entry for
  the Stage, else `graph.upstreams`') that is also a Stage of the project. A
  Stage with no such candidate takes Freight straight from the Warehouse.
- first: the last Stage, in order, that has no upstream. Every approver may
  promote it.
- autoPromote: a Stage with no upstream, and every Stage `autoPromote` lists;
  never a Stage `noAutoPromote` lists, which is marked `noAutoPromote` instead.
- noPrereleases: every Stage `noPrereleases` lists: its promotion refuses a
  version with a prerelease part.
- applications: `applicationsByStage` for the Stage, else `applications`, else
  the project's slug, each through `graph.applicationName` ({stage}, {app},
  and the project's tokens: cd-pipeline.projectTokens).
- e2eApplication: on the Stages `e2eStages` lists, `e2eApplication` (default
  `<slug>-e2e`) through `graph.applicationName`.
- verification: the promoted-version check when `graph.promotedVersion`, the
  metrics gate on the Stages `metricsGateStages` lists.
- source: `stageSources` for the Stage (a key of `sources`), else none (the
  project's `chart`); with customers, the customer's own source, or its
  source of that name (`<customer>-<source>`). A Stage and its upstream take
  the same source. When the
  project names any source, a Stage with no upstream that is not the first of
  `stageOrder` promotes by pull request, like a hop: it is a later cluster fed
  by a Warehouse of its own, not the project's first.
- access: with `access.approvers`, one subject per Stage but the first, named
  and claimed by `graph.approvers` ({stage}, {slug}), that may promote the first
  Stage and its own and, on the last Stage, approve Freight; with
  `access.admins`, one subject (`graph.admins`) that promotes every Stage and
  approves. Subjects listed in `access.subjects` come first, verbatim.
*/}}
{{- define "cd-pipeline.derive" -}}
{{- $v := .root.Values -}}
{{- $g := $v.graph | default dict -}}
{{- $p := deepCopy .p -}}
{{- $name := $p.name -}}
{{- $slug := $p.slug | default $name -}}
{{- $order := $p.stageOrder -}}
{{- if $p.stages -}}
{{- fail (printf "cd-pipeline: projects.%s sets both stages and stageOrder; a project spells its Stages out or derives them, not both" $name) -}}
{{- end -}}
{{- /* CUSTOMERS: one Kargo Project for a product with several customers.
       Each customer gets a Warehouse of its own, `<warehouse>-<customer>` (a
       source named after it, on the project's chart unless the customer
       names one), and its own chain of Stages, one for each Stage of
       stageOrder, named by graph.stageName (default `{stage}-{customer}`).
       A customer's Stages request only its Warehouse and promote only from
       its own Stages; the first of each chain promotes on its own. In the
       names of its Applications and in its pins, `{stage}` stays the Stage
       of stageOrder (the cluster) and `{customer}` is the customer. */ -}}
{{- $customers := list -}}
{{- range $c := ($p.customers | default list) -}}
{{- $customers = append $customers (ternary (dict "name" $c) $c (kindIs "string" $c)) -}}
{{- end -}}
{{- /* The sources the project names: with customers, `sources` is replaced
       below by one source per customer, and one per customer and named
       source. */ -}}
{{- $named := $p.sources | default dict -}}
{{- if $customers -}}
{{- $srcs := dict -}}
{{- $seen := dict -}}
{{- range $c := $customers -}}
{{- if hasKey $seen $c.name -}}{{- fail (printf "cd-pipeline: projects.%s.customers: %q is listed twice" $name $c.name) -}}{{- end -}}
{{- $_ := set $seen $c.name true -}}
{{- if hasKey $srcs $c.name -}}{{- fail (printf "cd-pipeline: projects.%s.customers: %q is also another customer's Warehouse of a source (<customer>-<source>); name the customer or the source apart" $name $c.name) -}}{{- end -}}
{{- $_ := set $srcs $c.name ($c.chart | default $p.chart | default dict) -}}
{{- /* A customer's own semver for a companion, in its Warehouse alone. */ -}}
{{- with $c.companions -}}
{{- $own := include "cd-pipeline.companionsFrom" (dict "companions" ($p.companions | default dict) "source" "") | fromYaml -}}
{{- range $cn, $co := . -}}
{{- if not (hasKey $own $cn) -}}{{- fail (printf "cd-pipeline: projects.%s.customers.%s.companions: %q is not a companion of the project" $name $c.name $cn) -}}{{- end -}}
{{- $_ := set (index $own $cn) "semver" $co.semver -}}
{{- end -}}
{{- $sc := $p.sourceCompanions | default dict -}}
{{- $_ := set $sc $c.name $own -}}
{{- $_ := set $p "sourceCompanions" $sc -}}
{{- end -}}
{{- /* Each named source, for this customer: a Warehouse
       `<warehouse>-<customer>-<source>` on the customer's chart from that
       source (customers[].sources.<source>, else the project's
       sources.<source>), with every companion from that source
       (companions.<name>.sources.<source>, else the companion as it is). */ -}}
{{- range $sn := keys ($c.sources | default dict) | sortAlpha -}}
{{- if not (hasKey $named $sn) -}}{{- fail (printf "cd-pipeline: projects.%s.customers.%s.sources: %q is not a key of sources" $name $c.name $sn) -}}{{- end -}}
{{- end -}}
{{- range $sn := keys $named | sortAlpha -}}
{{- $key := printf "%s-%s" $c.name $sn -}}
{{- if or (hasKey $srcs $key) (hasKey $seen $key) -}}{{- fail (printf "cd-pipeline: projects.%s: customer %q's Warehouse of source %q is named %q, as another customer's is; name the customer or the source apart" $name $c.name $sn $key) -}}{{- end -}}
{{- $_ := set $srcs $key (index ($c.sources | default dict) $sn | default (index $named $sn)) -}}
{{- with $p.companions -}}
{{- $sc := $p.sourceCompanions | default dict -}}
{{- $_ := set $sc $key (include "cd-pipeline.companionsFrom" (dict "companions" . "source" $sn) | fromYaml) -}}
{{- $_ := set $p "sourceCompanions" $sc -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- $_ := set $p "sources" $srcs -}}
{{- $_ := set $p "namedSources" (keys $named | sortAlpha) -}}
{{- end -}}
{{- $chains := deepCopy ($g.upstreams | default dict) -}}
{{- range $st, $cands := ($p.upstreams | default dict) -}}{{- $_ := set $chains $st $cands -}}{{- end -}}
{{- $auto := $p.autoPromote | default list -}}
{{- $noAuto := $p.noAutoPromote | default list -}}
{{- range $st := $noAuto -}}
{{- if not (has $st $order) -}}
{{- fail (printf "cd-pipeline: projects.%s.noAutoPromote: %q is not a Stage of stageOrder" $name $st) -}}
{{- end -}}
{{- end -}}
{{- $noPre := $p.noPrereleases | default list -}}
{{- range $st := $noPre -}}
{{- if not (has $st $order) -}}
{{- fail (printf "cd-pipeline: projects.%s.noPrereleases: %q is not a Stage of stageOrder" $name $st) -}}
{{- end -}}
{{- end -}}
{{- $upstream := dict -}}
{{- $first := "" -}}
{{- range $st := $order -}}
{{- range $u := (index $chains $st | default list) -}}
{{- if and (has $u $order) (not (hasKey $upstream $st)) -}}{{- $_ := set $upstream $st $u -}}{{- end -}}
{{- end -}}
{{- if not (hasKey $upstream $st) -}}{{- $first = $st -}}{{- end -}}
{{- end -}}
{{- $last := last $order -}}
{{- $srcOf := $p.stageSources | default dict -}}
{{- $sources := $p.sources | default dict -}}
{{- range $st := keys $srcOf | sortAlpha -}}
{{- if not (has $st $order) -}}
{{- fail (printf "cd-pipeline: projects.%s.stageSources: %q is not a Stage of stageOrder" $name $st) -}}
{{- end -}}
{{- if not (hasKey $named (index $srcOf $st)) -}}
{{- fail (printf "cd-pipeline: projects.%s.stageSources.%s: %q is not a key of sources" $name $st (index $srcOf $st)) -}}
{{- end -}}
{{- end -}}
{{- range $st := $order -}}
{{- if hasKey $upstream $st -}}
{{- $u := index $upstream $st -}}
{{- if ne (index $srcOf $st | default "") (index $srcOf $u | default "") -}}
{{- fail (printf "cd-pipeline: projects.%s: Stage %q takes source %q but its upstream %q takes %q; a Stage promotes only Freight of its own source (give it no upstream to take it straight from its Warehouse)" $name $st (index $srcOf $st | default "chart") $u (index $srcOf $u | default "chart")) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- $appName := $g.applicationName | default "{stage}-{app}" -}}
{{- include "cd-pipeline.checkTokens" (dict "p" $p "where" "graph.applicationName" "s" $appName) -}}
{{- $projectTokens := include "cd-pipeline.projectTokens" $p | fromYaml -}}
{{- $e2eApp := $p.e2eApplication | default (printf "%s-e2e" $slug) -}}
{{- $stages := list -}}
{{- $stageName := $g.stageName | default "{stage}-{customer}" -}}
{{- $chainsOf := ternary $customers (list (dict)) (gt (len $customers) 0) -}}
{{- $firsts := list -}}
{{- range $c := $chainsOf -}}
{{- $ctok := $projectTokens -}}
{{- if $c.name -}}{{- $ctok = merge (dict "customer" $c.name) $projectTokens -}}{{- end -}}
{{- range $st := $order -}}
{{- $apps := list -}}
{{- range $a := (index ($p.applicationsByStage | default dict) $st | default $p.applications | default (list $slug)) -}}
{{- $apps = append $apps (include "cd-pipeline.fill" (dict "s" $appName "tokens" (merge (dict "stage" $st "app" $a) $ctok))) -}}
{{- end -}}
{{- $sname := $st -}}
{{- if $c.name -}}{{- $sname = include "cd-pipeline.fill" (dict "s" $stageName "tokens" (dict "stage" $st "customer" $c.name)) -}}{{- end -}}
{{- $s := dict "name" $sname "applications" $apps -}}
{{- if $c.name -}}{{- $_ := set $s "env" $st -}}{{- $_ := set $s "customer" $c.name -}}{{- end -}}
{{- if hasKey $upstream $st -}}
{{- $u := index $upstream $st -}}
{{- if $c.name -}}{{- $u = include "cd-pipeline.fill" (dict "s" $stageName "tokens" (dict "stage" $u "customer" $c.name)) -}}{{- end -}}
{{- $_ := set $s "from" $u -}}
{{- else -}}
{{- $firsts = append $firsts $sname -}}
{{- end -}}
{{- /* The opt-out wins over both rules. */ -}}
{{- if has $st $noAuto -}}{{- $_ := set $s "noAutoPromote" true -}}
{{- else if or (not (hasKey $upstream $st)) (has $st $auto) -}}{{- $_ := set $s "autoPromote" true -}}{{- end -}}
{{- if has $st $noPre -}}{{- $_ := set $s "noPrereleases" true -}}{{- end -}}
{{- $stChart := $p.chart | default dict -}}
{{- /* A customer's Stage takes its customer's Warehouse, or, where
       stageSources names a source, its customer's Warehouse of that source. */ -}}
{{- $src := index $srcOf $st | default "" -}}
{{- if $c.name -}}{{- $src = ternary (printf "%s-%s" $c.name $src) $c.name (ne $src "") -}}{{- end -}}
{{- with $src -}}
{{- $_ := set $s "source" . -}}
{{- $stChart = index $sources . -}}
{{- end -}}
{{- if and $named (not (hasKey $upstream $st)) (ne $st (first $order)) -}}{{- $_ := set $s "mode" "pr" -}}{{- end -}}
{{- if has $st ($p.e2eStages | default list) -}}
{{- $_ := set $s "e2eApplication" (include "cd-pipeline.fill" (dict "s" $appName "tokens" (merge (dict "stage" $st "app" $e2eApp) $ctok))) -}}
{{- end -}}
{{- /* A digest pin has no chart version for the check to compare: the Stage omits it. */ -}}
{{- $verif := dict "promotedVersion" (and ($g.promotedVersion | default false) (ne ($stChart.pin | default "tag") "digest")) -}}
{{- if has $st ($p.metricsGateStages | default list) -}}{{- $_ := set $verif "metricsGate" true -}}{{- end -}}
{{- $_ := set $s "verification" $verif -}}
{{- $stages = append $stages $s -}}
{{- end -}}
{{- end -}}
{{- $acc := $p.access | default dict -}}
{{- $subjects := $acc.subjects | default list -}}
{{- if $acc.approvers -}}
{{- $ap := $g.approvers | default dict -}}
{{- $claims := $ap.claims -}}
{{- if not $claims -}}{{- fail "cd-pipeline: graph.approvers.claims is required by access.approvers" -}}{{- end -}}
{{- range $c := $chainsOf -}}
{{- $cfirst := $first -}}
{{- if $c.name -}}{{- $cfirst = include "cd-pipeline.fill" (dict "s" $stageName "tokens" (dict "stage" $first "customer" $c.name)) -}}{{- end -}}
{{- range $st := $order -}}
{{- if ne $st $first -}}
{{- $tokens := dict "stage" $st "slug" $slug "project" $name -}}
{{- $sname := $st -}}
{{- /* One approver for each customer's Stage: a subject name that does not
       spell the customer takes it as a suffix. */ -}}
{{- $subj := $ap.subject | default "approver-{stage}" -}}
{{- if $c.name -}}
{{- if not (contains "{customer}" $subj) -}}{{- $subj = printf "%s-{customer}" $subj -}}{{- end -}}
{{- $_ := set $tokens "customer" $c.name -}}
{{- $sname = include "cd-pipeline.fill" (dict "s" $stageName "tokens" (dict "stage" $st "customer" $c.name)) -}}
{{- end -}}
{{- $subjects = append $subjects (dict "name" (include "cd-pipeline.fill" (dict "s" $subj "tokens" $tokens)) "claims" (include "cd-pipeline.fillClaims" (dict "claims" $claims "tokens" $tokens) | fromYaml) "stages" (list $cfirst $sname) "approve" (eq $st $last)) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- $allNames := list -}}
{{- range $s := $stages -}}{{- $allNames = append $allNames $s.name -}}{{- end -}}
{{- if $acc.admins -}}
{{- $ad := $g.admins | default dict -}}
{{- $claims := $ad.claims -}}
{{- if not $claims -}}{{- fail "cd-pipeline: graph.admins.claims is required by access.admins" -}}{{- end -}}
{{- $tokens := dict "slug" $slug "project" $name -}}
{{- $subjects = append $subjects (dict "name" ($ad.subject | default "admin") "claims" (include "cd-pipeline.fillClaims" (dict "claims" $claims "tokens" $tokens) | fromYaml) "stages" $allNames "approve" true) -}}
{{- end -}}
{{- $_ := set $p "access" (dict "subjects" $subjects) -}}
{{- $_ := set $p "stages" $stages -}}
{{- if $customers -}}{{- $_ := set $p "customerWarehousesOnly" true -}}{{- end -}}
{{- range $k := list "stageOrder" "upstreams" "autoPromote" "noAutoPromote" "noPrereleases" "stageSources" "applications" "applicationsByStage" "e2eStages" "e2eApplication" "metricsGateStages" "customers" -}}
{{- $_ := unset $p $k -}}
{{- end -}}
{{- toYaml $p -}}
{{- end -}}

{{/*
A claims map with its tokens filled: every string, and every string of a list,
through cd-pipeline.fill. As YAML for `fromYaml`.
Call with (dict "claims" <map> "tokens" <map>).
*/}}
{{- define "cd-pipeline.fillClaims" -}}
{{- $out := dict -}}
{{- $tokens := .tokens -}}
{{- range $k, $v := .claims -}}
{{- if kindIs "slice" $v -}}
{{- $l := list -}}
{{- range $x := $v -}}{{- $l = append $l (ternary (include "cd-pipeline.fill" (dict "s" (toString $x) "tokens" $tokens)) $x (kindIs "string" $x)) -}}{{- end -}}
{{- $_ := set $out $k $l -}}
{{- else if kindIs "string" $v -}}
{{- $_ := set $out $k (include "cd-pipeline.fill" (dict "s" $v "tokens" $tokens)) -}}
{{- else -}}
{{- $_ := set $out $k $v -}}
{{- end -}}
{{- end -}}
{{- toYaml $out -}}
{{- end -}}

{{/*
The metrics gate of a Stage, as one `verification.checks` entry: a Job that
waits until the promoted version is the only one serving, then bakes on a
sample count of prober journeys read from a Prometheus-compatible endpoint
(files/verify-metrics-gate.sh, or the promotion-gate image's `metrics-gate`
with `metricsGate.gateImage`). As YAML for `fromYaml`.
Call with (dict "root" . "p" <project> "s" <stage> "slug" ..).
*/}}
{{- define "cd-pipeline.metricsGateCheck" -}}
{{- $r := .root -}}
{{- $v := $r.Values -}}
{{- $mg := $v.metricsGate -}}
{{- $p := .p -}}
{{- $s := .s -}}
{{- $slug := .slug -}}
{{- $pg := $p.metricsGate | default dict -}}
{{- $ep := required (printf "cd-pipeline: metricsGate.endpoints.%s is required by the metrics gate of projects.%s" ($s.env | default $s.name) $p.name) (index ($mg.endpoints | default dict) ($s.env | default $s.name)) -}}
{{- $tok := $mg.token -}}
{{- $ca := $mg.caBundle -}}
{{- $tokens := dict "stage" $s.name "slug" $slug "project" $p.name -}}
{{- $env := list (dict "name" "CHART_VERSION" "value" "{{args.chart-version}}") (dict "name" "PROJECT_NAME" "value" $slug) (dict "name" "ISSUER_HOST" "value" (required "cd-pipeline: metricsGate.issuerHost is required by a metrics gate" $mg.issuerHost)) (dict "name" "METRICS_BASE_URL" "value" (required (printf "cd-pipeline: metricsGate.endpoints.%s.url is required" ($s.env | default $s.name)) $ep.url)) (dict "name" "SA_TOKEN_FILE" "value" (printf "%s/token" $tok.mountPath)) -}}
{{- if $ep.caBundle -}}
{{- $env = append $env (dict "name" "CA_BUNDLE" "value" (printf "%s/%s" $ca.mountPath $ca.key)) -}}
{{- end -}}
{{- $env = concat $env (list (dict "name" "WORKLOAD_NAMESPACE" "value" ($pg.namespace | default $slug)) (dict "name" "WORKLOAD_RELEASE" "value" ($pg.release | default $slug)) (dict "name" "PHASE1_SECONDS" "value" (toString $mg.phase1Seconds)) (dict "name" "BAKE_SECONDS" "value" (toString $mg.bakeSeconds)) (dict "name" "SCRAPE_LAG_SECONDS" "value" (toString $mg.scrapeLagSeconds)) (dict "name" "POLL_SECONDS" "value" (toString $mg.pollSeconds)) (dict "name" "MIN_JOURNEYS" "value" (toString $mg.minJourneys)) (dict "name" "MAX_FAILURE_RATIO" "value" (toString $mg.maxFailureRatio)) (dict "name" "CHECK_FIRING_ALERTS" "value" (toString $mg.checkFiringAlerts)) (dict "name" "PROBER_JOURNEY_METRIC" "value" (toString $mg.proberJourneyMetric)) (dict "name" "E2E_JOB_REQUIRED" "value" (toString (ternary $pg.e2eJobRequired true (hasKey $pg "e2eJobRequired"))))) -}}
{{- $mounts := list (dict "name" $tok.volumeName "mountPath" $tok.mountPath "readOnly" true) -}}
{{- $vols := list (dict "name" $tok.volumeName "projected" (dict "sources" (list (dict "serviceAccountToken" (dict "audience" (required "cd-pipeline: metricsGate.token.audience is required by a metrics gate" $tok.audience) "expirationSeconds" $tok.expirationSeconds "path" "token"))))) -}}
{{- if $ep.caBundle -}}
{{- $mounts = append $mounts (dict "name" $ca.volumeName "mountPath" $ca.mountPath "readOnly" true) -}}
{{- $vols = append $vols (dict "name" $ca.volumeName "configMap" (dict "name" (required "cd-pipeline: metricsGate.caBundle.configMap is required by an endpoint with caBundle" $ca.configMap))) -}}
{{- end -}}
{{- $check := dict "name" (printf "%s-%s-metrics-gate" $slug $s.name) "metric" "metrics-gate" "serviceAccount" (include "cd-pipeline.fill" (dict "s" $mg.serviceAccount "tokens" $tokens)) -}}
{{- if $mg.gateImage -}}
{{- $_ := set $check "image" $mg.gateImage -}}
{{- $_ := set $check "command" (list "/ko-app/promotion-gate" "metrics-gate") -}}
{{- else -}}
{{- $pv := $v.promotedVersion -}}
{{- $_ := set $check "image" (required "cd-pipeline: metricsGate.image (or promotedVersion.image) is required by a metrics gate" ($mg.image | default $pv.image)) -}}
{{- $_ := set $check "script" (dict "configMap" (printf "%s-%s-verify-metrics-gate" $slug $s.name) "file" "verify-metrics-gate.sh" "content" ($r.Files.Get "files/verify-metrics-gate.sh")) -}}
{{- $env = append $env (dict "name" "JQ" "value" "/opt/jq/jq") -}}
{{- $mounts = append $mounts (dict "name" "jq-tool" "mountPath" "/opt/jq" "readOnly" true) -}}
{{- $vols = append $vols (dict "name" "jq-tool" "image" (dict "reference" (required "cd-pipeline: metricsGate.jqImage (or promotedVersion.jqImage) is required by a metrics gate" ($mg.jqImage | default $pv.jqImage)) "pullPolicy" "IfNotPresent")) -}}
{{- end -}}
{{- $_ := set $check "env" $env -}}
{{- $_ := set $check "volumeMounts" $mounts -}}
{{- $_ := set $check "volumes" $vols -}}
{{- $_ := set $check "deadlineSeconds" (add (int $mg.phase1Seconds) (int $mg.bakeSeconds) (int $v.jobs.headroomSeconds)) -}}
{{- toYaml $check -}}
{{- end -}}
