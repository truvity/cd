{{/*
One project: its Project, Warehouse, credentials, configuration, access and
Stages, as YAML documents. Call with (dict "root" . "p" <project map>).
*/}}
{{- define "cd-pipeline.project" -}}
{{- $r := .root -}}
{{- $v := $r.Values -}}
{{- $p := deepCopy .p -}}
{{- $w := $v.waves -}}
{{- $name := $p.name -}}
{{- $slug := $p.slug | default $name -}}
{{- $chart := $p.chart | default dict -}}
{{- $repoURL := $chart.repoURL | default "" -}}
{{- $chartName := $chart.name | default "" -}}
{{- $wh := $p.warehouse | default dict -}}
{{- $eff := include "cd-pipeline.effective" (dict "root" $r "p" $p) | fromYaml -}}
{{- $whName := $wh.name | default $name -}}
{{- if $p.customers -}}
{{- fail (printf "cd-pipeline: projects.%s.customers needs stageOrder: a customer's chain of Stages is derived" $name) -}}
{{- end -}}
{{- /* The companions of each further source: a companion may name its
       artifact from a source (companions.<name>.sources.<source>), so that
       a Warehouse of preview charts holds preview artifacts beside them.
       The customers' sources were filled by cd-pipeline.derive. */ -}}
{{- $companionsOf := $p.sourceCompanions | default dict -}}
{{- with $p.companions -}}
{{- $named := $p.namedSources | default (keys ($p.sources | default dict)) -}}
{{- range $cn := keys . | sortAlpha -}}
{{- range $sn := keys ((index $p.companions $cn).sources | default dict) | sortAlpha -}}
{{- if not (has $sn $named) -}}{{- fail (printf "cd-pipeline: projects.%s.companions.%s.sources: %q is not a key of sources" $name $cn $sn) -}}{{- end -}}
{{- end -}}
{{- end -}}
{{- range $sn := keys ($p.sources | default dict) | sortAlpha -}}
{{- if not (hasKey $companionsOf $sn) -}}
{{- $_ := set $companionsOf $sn (include "cd-pipeline.companionsFrom" (dict "companions" $p.companions "source" $sn) | fromYaml) -}}
{{- end -}}
{{- end -}}
{{- $_ := set $p "companions" (include "cd-pipeline.companionsFrom" (dict "companions" $p.companions "source" "") | fromYaml) -}}
{{- end -}}
{{- include "cd-pipeline.checkCompanions" $p -}}
{{- range $sn := keys $companionsOf | sortAlpha -}}
{{- include "cd-pipeline.checkCompanions" (dict "name" (printf "%s (source %s)" $name $sn) "chart" (index $p.sources $sn) "companions" (index $companionsOf $sn)) -}}
{{- end -}}

{{- /* Project: cluster-scoped, so an installation that hands the rest of the
pipeline to another party may render it elsewhere (createProject: false). */ -}}
{{- if ne $p.createProject false -}}
{{- include "cd-pipeline.doc" (dict "apiVersion" "kargo.akuity.io/v1alpha1" "kind" "Project" "metadata" (include "cd-pipeline.meta" (dict "root" $r "name" $name "wave" $w.project "annotations" $p.annotations) | fromYaml)) -}}
{{- else if $p.annotations -}}
{{- fail (printf "cd-pipeline: projects.%s.annotations are the Project's own, and createProject: false renders no Project" $name) -}}
{{- end -}}

{{- /* Warehouse: one chart subscription unless the project lists its own. */ -}}
{{- /* A project with customers has a Warehouse for each customer and none
       of its own (cd-pipeline.derive). */ -}}
{{- if not $p.customerWarehousesOnly -}}
{{- include "cd-pipeline.warehouse" (dict "root" $r "name" $name "whName" $whName "wh" $wh "chart" $chart "subs" $wh.subscriptions "where" "chart" "companions" $p.companions) -}}
{{- end -}}
{{- /* A Warehouse per further source, <warehouse>-<source>, with the same
       interval and Freight policy; `warehouse.subscriptions` is `chart`'s alone. */ -}}
{{- $sources := $p.sources | default dict -}}
{{- range $sn := keys $sources | sortAlpha -}}
{{- include "cd-pipeline.warehouse" (dict "root" $r "name" $name "whName" (printf "%s-%s" $whName $sn) "wh" $wh "chart" (index $sources $sn) "subs" list "where" (printf "sources.%s" $sn) "companions" (index $companionsOf $sn | default $p.companions)) -}}
{{- end -}}

{{- /* The credentials a promotion writes back with: one ExternalSecret per project namespace. */ -}}
{{- $cred := $eff.git.credentials -}}
{{- if $cred -}}
{{- $secret := $cred.secretName | default "kargo-git-writeback" -}}
{{- $props := required "cd-pipeline: git.credentials.properties is required" $cred.properties -}}
{{- $data := list -}}
{{- range $pair := (list (list "githubAppID" $props.appID) (list "githubInstallationID" $props.installationID) (list "githubPrivateKey" $props.privateKey)) -}}
{{- $data = append $data (dict "secretKey" (index $pair 0) "remoteRef" (dict "key" (required "cd-pipeline: git.credentials.remoteKey is required" $cred.remoteKey) "property" (index $pair 1) "conversionStrategy" "Default" "decodingStrategy" "None" "metadataPolicy" "None" "nullBytePolicy" "Ignore")) -}}
{{- end -}}
{{- $tmplData := dict "repoURL" (required (printf "cd-pipeline: projects.%s: git.repoURL is required (the release's git.repoURL, or the project's own)" $name) $eff.git.repoURL) "githubAppID" `{{ .githubAppID }}` "githubAppInstallationID" `{{ .githubInstallationID }}` "githubAppPrivateKey" `{{ .githubPrivateKey }}` -}}
{{- $es := dict "apiVersion" "external-secrets.io/v1" "kind" "ExternalSecret" "metadata" (include "cd-pipeline.meta" (dict "root" $r "name" "kargo-git-writeback" "ns" $name "wave" $w.credentials) | fromYaml) -}}
{{- $_ := set $es.metadata "name" $secret -}}
{{- $_ := set $es "spec" (dict "refreshInterval" ($cred.refreshInterval | default "1h") "secretStoreRef" (dict "kind" $cred.secretStoreRef.kind "name" $cred.secretStoreRef.name) "target" (dict "name" $secret "creationPolicy" "Owner" "template" (dict "metadata" (dict "labels" (dict "kargo.akuity.io/cred-type" "git")) "data" $tmplData)) "data" $data) -}}
{{- include "cd-pipeline.doc" $es -}}
{{- end -}}

{{- /* ProjectConfig: which Stages promote on their own. */ -}}
{{- $policies := list -}}
{{- range $s := $p.stages -}}
{{- /* A Stage marked `noAutoPromote` says so in the ProjectConfig: a policy
       left behind by an earlier render cannot keep it promoting. */ -}}
{{- if $s.noAutoPromote -}}{{- $policies = append $policies (dict "stage" $s.name "autoPromotionEnabled" false) -}}
{{- else if $s.autoPromote -}}{{- $policies = append $policies (dict "stage" $s.name "autoPromotionEnabled" true) -}}{{- end -}}
{{- end -}}
{{- if $policies -}}
{{- include "cd-pipeline.doc" (dict "apiVersion" "kargo.akuity.io/v1alpha1" "kind" "ProjectConfig" "metadata" (include "cd-pipeline.meta" (dict "root" $r "name" $name "ns" $name "wave" $w.config) | fromYaml) "spec" (dict "promotionPolicies" $policies)) -}}
{{- end -}}

{{- /* Who may promote: a ServiceAccount, Role and RoleBinding per subject. Kargo maps a token to every ServiceAccount whose claims annotation matches it. */ -}}
{{- range $s := ($p.access).subjects -}}
{{- $sa := dict "apiVersion" "v1" "kind" "ServiceAccount" "metadata" (include "cd-pipeline.meta" (dict "root" $r "name" $s.name "ns" $name "wave" $w.config "annotations" (dict "rbac.kargo.akuity.io/claims" (toJson $s.claims))) | fromYaml) -}}
{{- $rules := list (dict "apiGroups" (list "kargo.akuity.io") "resources" (list "freights" "stages" "warehouses" "projectconfigs" "promotions") "verbs" (list "get" "list" "watch")) (dict "apiGroups" (list "kargo.akuity.io") "resources" (list "stages") "resourceNames" $s.stages "verbs" (list "promote")) (dict "apiGroups" (list "kargo.akuity.io") "resources" (list "promotions") "verbs" (list "create")) -}}
{{- if $s.approve -}}{{- $rules = append $rules (dict "apiGroups" (list "kargo.akuity.io") "resources" (list "freights/status") "verbs" (list "patch")) -}}{{- end -}}
{{- include "cd-pipeline.doc" $sa -}}
{{- include "cd-pipeline.doc" (dict "apiVersion" "rbac.authorization.k8s.io/v1" "kind" "Role" "metadata" (include "cd-pipeline.meta" (dict "root" $r "name" $s.name "ns" $name "wave" $w.config) | fromYaml) "rules" $rules) -}}
{{- include "cd-pipeline.doc" (dict "apiVersion" "rbac.authorization.k8s.io/v1" "kind" "RoleBinding" "metadata" (include "cd-pipeline.meta" (dict "root" $r "name" $s.name "ns" $name "wave" $w.config) | fromYaml) "roleRef" (dict "apiGroup" "rbac.authorization.k8s.io" "kind" "Role" "name" $s.name) "subjects" (list (dict "kind" "ServiceAccount" "name" $s.name "namespace" $name))) -}}
{{- end -}}

{{- /* Read-only for everyone the viewer ServiceAccount covers. */ -}}
{{- with $v.viewer.serviceAccount -}}
{{- $vw := $v.viewer -}}
{{- include "cd-pipeline.doc" (dict "apiVersion" "rbac.authorization.k8s.io/v1" "kind" "RoleBinding" "metadata" (include "cd-pipeline.meta" (dict "root" $r "name" ($vw.bindingName | default "viewer") "ns" $name "wave" $w.config) | fromYaml) "roleRef" (dict "apiGroup" "rbac.authorization.k8s.io" "kind" "Role" "name" (required "cd-pipeline: viewer.role is required" $vw.role)) "subjects" (list (dict "kind" "ServiceAccount" "name" $vw.serviceAccount "namespace" (required "cd-pipeline: viewer.namespace is required" $vw.namespace)))) -}}
{{- end -}}

{{- /* The Stages, each with the checks it verifies by. */ -}}
{{- $stages := dict -}}
{{- range $s := $p.stages -}}{{- $_ := set $stages $s.name $s -}}{{- end -}}
{{- range $s := $p.stages -}}
{{- if and $s.from (not (hasKey $stages $s.from)) -}}{{- fail (printf "cd-pipeline: projects.%s.stages.%s.from names %q, which is not a stage of the project" $name $s.name $s.from) -}}{{- end -}}
{{- /* A Stage with a source takes that source's Warehouse and chart: its
       Freight, its promotion's chart and its checks all read the project
       map's `chart`, so the Stage is rendered with the source in its place. */ -}}
{{- $ps := $p -}}
{{- $sw := $whName -}}
{{- with $s.source -}}
{{- if not (hasKey $sources .) -}}{{- fail (printf "cd-pipeline: projects.%s.stages.%s.source: %q is not a key of sources" $name $s.name .) -}}{{- end -}}
{{- $ps = deepCopy $p -}}
{{- $_ := set $ps "chart" (index $sources .) -}}
{{- with index $companionsOf . -}}{{- $_ := set $ps "companions" . -}}{{- end -}}
{{- $sw = printf "%s-%s" $whName . -}}
{{- end -}}
{{- if $s.from -}}
{{- $us := (get $stages $s.from).source | default "" -}}
{{- if ne ($s.source | default "") $us -}}{{- fail (printf "cd-pipeline: projects.%s.stages.%s takes source %q but its upstream %q takes %q; a Stage promotes only Freight of its own source" $name $s.name ($s.source | default "chart") $s.from ($us | default "chart")) -}}{{- end -}}
{{- end -}}
{{- include "cd-pipeline.stage" (dict "root" $r "p" $ps "s" $s "stages" $stages "slug" $slug "whName" $sw "eff" $eff) -}}
{{- end -}}
{{- end -}}

{{/*
One Warehouse: a chart (or image) subscription to the chart given, unless
`subs` lists its own. Call with (dict "root" . "name" <project> "whName" ..
"wh" <warehouse settings> "chart" <chart map> "subs" <list> "where" <key path for messages>).
*/}}
{{- define "cd-pipeline.warehouse" -}}
{{- $r := .root -}}
{{- $w := $r.Values.waves -}}
{{- $name := .name -}}
{{- $chart := .chart | default dict -}}
{{- $wh := .wh -}}
{{- $subs := .subs -}}
{{- if and $subs .companions -}}
{{- fail (printf "cd-pipeline: projects.%s sets companions and warehouse.subscriptions; the subscriptions are verbatim, so the companions would not be in the Freight" $name) -}}
{{- end -}}
{{- if not $subs -}}
{{- $subs = list (include "cd-pipeline.subscription" (dict "name" $name "chart" $chart "where" .where) | fromYaml) -}}
{{- /* Every companion beside the chart: one Freight holds them all. */ -}}
{{- range $cn := keys (.companions | default dict) | sortAlpha -}}
{{- $subs = append $subs (include "cd-pipeline.subscription" (dict "name" $name "chart" (index $.companions $cn) "where" (printf "companions.%s" $cn)) | fromYaml) -}}
{{- end -}}
{{- end -}}
{{- $spec := dict "interval" ($wh.interval | default "5m0s") "freightCreationPolicy" ($wh.freightCreationPolicy | default "Automatic") "subscriptions" $subs -}}
{{- /* Freight is created only when the expression holds: the main Warehouse's alone, not a further source's. */ -}}
{{- if and (eq .where "chart") $wh.freightCreationCriteria -}}
{{- $_ := set $spec "freightCreationCriteria" $wh.freightCreationCriteria -}}
{{- end -}}
{{- include "cd-pipeline.doc" (dict "apiVersion" "kargo.akuity.io/v1alpha1" "kind" "Warehouse" "metadata" (include "cd-pipeline.meta" (dict "root" $r "name" .whName "ns" $name "wave" $w.warehouse) | fromYaml) "spec" $spec) -}}
{{- end -}}

{{/*
One Stage and the objects its verification needs.
Call with (dict "root" . "p" <project> "s" <stage> "stages" <name -> stage> "slug" .. "whName" .. "eff" <cd-pipeline.effective>).
*/}}
{{- define "cd-pipeline.stage" -}}
{{- $r := .root -}}
{{- $v := $r.Values -}}
{{- $p := .p -}}
{{- $s := .s -}}
{{- $w := $v.waves -}}
{{- $name := $p.name -}}
{{- $slug := .slug -}}
{{- $chart := $p.chart | default dict -}}
{{- $repoURL := $chart.repoURL | default "" -}}
{{- $chartName := $chart.name | default "" -}}
{{- $prefix := $chart.versionPrefix | default "" -}}
{{- $upstream := $s.from | default "" -}}
{{- $mode := include "cd-pipeline.chartMode" (dict "name" $name "chart" $chart) | fromYaml -}}
{{- $verArg := dict "name" "chart-version" "value" (printf "${{ %s.%s }}" (include "cd-pipeline.chartFrom" (dict "repoURL" $mode.repo "name" $chartName "vars" false "image" $mode.image)) (ternary "Tag" "Version" $mode.image)) -}}
{{- $verif := $s.verification | default dict -}}
{{- $templates := list -}}

{{- /* The promoted-version check: that the Applications of this Stage render the promoted chart. */ -}}
{{- if $verif.promotedVersion -}}
{{- if $mode.digest -}}{{- fail (printf "cd-pipeline: projects.%s.stages.%s.verification.promotedVersion: a digest pin has no chart version to compare with the Application's" $name $s.name) -}}{{- end -}}
{{- $pv := $v.promotedVersion -}}
{{- $apps := required (printf "cd-pipeline: projects.%s.stages.%s.applications is required for the promoted-version check" $name $s.name) $s.applications -}}
{{- $sa := printf "kargo-verify-%s" $s.name -}}
{{- $role := printf "kargo-verify-%s-%s" $name $s.name -}}
{{- $cm := printf "%s-%s-verify-promoted-version" $slug $s.name -}}
{{- $at := printf "%s-%s-promoted-version" $slug $s.name -}}
{{- $ns := $v.argocd.namespace -}}
{{- $templates = append $templates $at -}}
{{- /* With promotedVersion.objects false the Stage only names the check: its
       ServiceAccount, Role, RoleBinding and AnalysisTemplate are rendered by
       whoever owns the cluster the check runs on (a platform rendering a
       company's pipeline), under the same names. */ -}}
{{- if ne (toString $pv.objects) "false" -}}
{{- include "cd-pipeline.doc" (dict "apiVersion" "v1" "kind" "ServiceAccount" "metadata" (include "cd-pipeline.meta" (dict "root" $r "name" $sa "ns" $name "wave" $w.config) | fromYaml)) -}}
{{- include "cd-pipeline.doc" (dict "apiVersion" "rbac.authorization.k8s.io/v1" "kind" "Role" "metadata" (include "cd-pipeline.meta" (dict "root" $r "name" $role "ns" $ns "wave" $w.config) | fromYaml) "rules" (list (dict "apiGroups" (list "argoproj.io") "resources" (list "applications") "resourceNames" $apps "verbs" (list "get")))) -}}
{{- include "cd-pipeline.doc" (dict "apiVersion" "rbac.authorization.k8s.io/v1" "kind" "RoleBinding" "metadata" (include "cd-pipeline.meta" (dict "root" $r "name" $role "ns" $ns "wave" $w.config) | fromYaml) "roleRef" (dict "apiGroup" "rbac.authorization.k8s.io" "kind" "Role" "name" $role) "subjects" (list (dict "kind" "ServiceAccount" "name" $sa "namespace" $name))) -}}
{{- $env := list (dict "name" "APPS" "value" (join " " $apps)) (dict "name" "CHART_REPO" "value" $repoURL) (dict "name" "CHART_NAME" "value" $chartName) (dict "name" "EXPECTED" "value" (printf "%s%s" $prefix "{{args.chart-version}}")) (dict "name" "WAIT_SECONDS" "value" (toString (int $pv.waitSeconds))) (dict "name" "POLL_SECONDS" "value" (toString (int $pv.pollSeconds))) -}}
{{- if $pv.gateImage -}}
{{- /* The Go check (truvity/cd's promotion-gate image): no script, no jq. */ -}}
{{- if ne $ns "argocd" -}}{{- $env = append $env (dict "name" "ARGOCD_NAMESPACE" "value" $ns) -}}{{- end -}}
{{- include "cd-pipeline.jobCheck" (dict "root" $r "name" $at "ns" $name "metric" "promoted-version" "args" (list "chart-version") "sa" $sa "image" $pv.gateImage "command" (list "/ko-app/promotion-gate" "promoted-version") "env" $env "deadline" (add (int $pv.waitSeconds) $v.jobs.headroomSeconds)) -}}
{{- else -}}
{{- $script := $pv.script | default ($r.Files.Get "files/verify-promoted-version.sh") -}}
{{- include "cd-pipeline.doc" (dict "apiVersion" "v1" "kind" "ConfigMap" "metadata" (include "cd-pipeline.meta" (dict "root" $r "name" $cm "ns" $name "wave" $w.config) | fromYaml) "data" (dict "verify-promoted-version.sh" $script)) -}}
{{- $env = append $env (dict "name" "JQ" "value" "/opt/jq/jq") -}}
{{- if ne $ns "argocd" -}}{{- $env = append $env (dict "name" "ARGOCD_NAMESPACE" "value" $ns) -}}{{- end -}}
{{- $mounts := list (dict "name" "script" "mountPath" "/scripts" "readOnly" true) (dict "name" "jq-tool" "mountPath" "/opt/jq" "readOnly" true) -}}
{{- $vols := list (include "cd-pipeline.scriptVolume" (dict "configMap" $cm) | fromYaml) (dict "name" "jq-tool" "image" (dict "reference" (required "cd-pipeline: promotedVersion.jqImage is required" $pv.jqImage) "pullPolicy" "IfNotPresent")) -}}
{{- include "cd-pipeline.jobCheck" (dict "root" $r "name" $at "ns" $name "metric" "promoted-version" "args" (list "chart-version") "sa" $sa "image" (required "cd-pipeline: promotedVersion.image is required" $pv.image) "command" (list "/bin/sh" "/scripts/verify-promoted-version.sh") "env" $env "mounts" $mounts "volumes" $vols "deadline" (add (int $pv.waitSeconds) $v.jobs.headroomSeconds)) -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- /* One promoted-version check per companion, beside the chart's: each
       part of the release must be rendered by one of the Stage's
       Applications, so a part none renders fails on its own instead of
       being skipped. A companion pinned by digest is judged by its
       artifact (ARTIFACT_REF and the digest in the Applications' values),
       one pinned by tag as a chart of its own repository. */ -}}
{{- $verArgs := list $verArg -}}
{{- if $verif.promotedVersion -}}
{{- $pv := $v.promotedVersion -}}
{{- $ns := $v.argocd.namespace -}}
{{- range $cn := keys ($p.companions | default dict) | sortAlpha -}}
{{- $co := index $p.companions $cn -}}
{{- $cm := include "cd-pipeline.chartMode" (dict "name" $name "chart" $co) | fromYaml -}}
{{- $arg := printf "%s-%s" $cn (ternary "digest" "version" $cm.digest) -}}
{{- $from := include "cd-pipeline.chartFrom" (dict "repoURL" $cm.repo "name" ($co.name | default "") "vars" false "image" $cm.image) -}}
{{- $verArgs = append $verArgs (dict "name" $arg "value" (printf "${{ %s.%s }}" $from (ternary (ternary "Digest" "Tag" $cm.digest) "Version" $cm.image))) -}}
{{- $at := printf "%s-%s-promoted-%s" $slug $s.name $cn -}}
{{- $templates = append $templates $at -}}
{{- if ne (toString $pv.objects) "false" -}}
{{- $env := list (dict "name" "APPS" "value" (join " " $s.applications)) (dict "name" "CHART_REPO" "value" (ternary "" ($co.repoURL | default "") $cm.digest)) (dict "name" "CHART_NAME" "value" ($co.name | default "")) (dict "name" "EXPECTED" "value" (printf "%s{{args.%s}}" (ternary "" ($co.versionPrefix | default "") $cm.digest) $arg)) -}}
{{- if $cm.digest -}}{{- $env = append $env (dict "name" "ARTIFACT_REF" "value" $cm.repo) -}}{{- end -}}
{{- $env = concat $env (list (dict "name" "WAIT_SECONDS" "value" (toString (int $pv.waitSeconds))) (dict "name" "POLL_SECONDS" "value" (toString (int $pv.pollSeconds)))) -}}
{{- $sa := printf "kargo-verify-%s" $s.name -}}
{{- if $pv.gateImage -}}
{{- if ne $ns "argocd" -}}{{- $env = append $env (dict "name" "ARGOCD_NAMESPACE" "value" $ns) -}}{{- end -}}
{{- include "cd-pipeline.jobCheck" (dict "root" $r "name" $at "ns" $name "metric" "promoted-version" "args" (list $arg) "sa" $sa "image" $pv.gateImage "command" (list "/ko-app/promotion-gate" "promoted-version") "env" $env "deadline" (add (int $pv.waitSeconds) $v.jobs.headroomSeconds)) -}}
{{- else -}}
{{- $cmName := printf "%s-%s-verify-promoted-version" $slug $s.name -}}
{{- $env = append $env (dict "name" "JQ" "value" "/opt/jq/jq") -}}
{{- if ne $ns "argocd" -}}{{- $env = append $env (dict "name" "ARGOCD_NAMESPACE" "value" $ns) -}}{{- end -}}
{{- $mounts := list (dict "name" "script" "mountPath" "/scripts" "readOnly" true) (dict "name" "jq-tool" "mountPath" "/opt/jq" "readOnly" true) -}}
{{- $vols := list (include "cd-pipeline.scriptVolume" (dict "configMap" $cmName) | fromYaml) (dict "name" "jq-tool" "image" (dict "reference" (required "cd-pipeline: promotedVersion.jqImage is required" $pv.jqImage) "pullPolicy" "IfNotPresent")) -}}
{{- include "cd-pipeline.jobCheck" (dict "root" $r "name" $at "ns" $name "metric" "promoted-version" "args" (list $arg) "sa" $sa "image" (required "cd-pipeline: promotedVersion.image is required" $pv.image) "command" (list "/bin/sh" "/scripts/verify-promoted-version.sh") "env" $env "mounts" $mounts "volumes" $vols "deadline" (add (int $pv.waitSeconds) $v.jobs.headroomSeconds)) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- /* The end-to-end operation check: that the Promotion's sync of the end-to-end Application ran the suite hook for the promoted version and it succeeded. */ -}}
{{- if $s.e2eApplication -}}
{{- $pv := $v.promotedVersion -}}
{{- $app := $s.e2eApplication -}}
{{- $sa := printf "kargo-verify-%s" $s.name -}}
{{- $role := printf "kargo-verify-%s-%s-e2e" $name $s.name -}}
{{- $cm := printf "%s-%s-verify-e2e-operation" $slug $s.name -}}
{{- $at := printf "%s-%s-e2e-operation" $slug $s.name -}}
{{- $ns := $v.argocd.namespace -}}
{{- $templates = append $templates $at -}}
{{- /* The promoted-version check renders this ServiceAccount when it is on and renders its objects. */ -}}
{{- if or (not $verif.promotedVersion) (eq (toString ($v.promotedVersion | default dict).objects) "false") -}}
{{- include "cd-pipeline.doc" (dict "apiVersion" "v1" "kind" "ServiceAccount" "metadata" (include "cd-pipeline.meta" (dict "root" $r "name" $sa "ns" $name "wave" $w.config) | fromYaml)) -}}
{{- end -}}
{{- include "cd-pipeline.doc" (dict "apiVersion" "rbac.authorization.k8s.io/v1" "kind" "Role" "metadata" (include "cd-pipeline.meta" (dict "root" $r "name" $role "ns" $ns "wave" $w.config) | fromYaml) "rules" (list (dict "apiGroups" (list "argoproj.io") "resources" (list "applications") "resourceNames" (list $app) "verbs" (list "get")))) -}}
{{- include "cd-pipeline.doc" (dict "apiVersion" "rbac.authorization.k8s.io/v1" "kind" "RoleBinding" "metadata" (include "cd-pipeline.meta" (dict "root" $r "name" $role "ns" $ns "wave" $w.config) | fromYaml) "roleRef" (dict "apiGroup" "rbac.authorization.k8s.io" "kind" "Role" "name" $role) "subjects" (list (dict "kind" "ServiceAccount" "name" $sa "namespace" $name))) -}}
{{- include "cd-pipeline.doc" (dict "apiVersion" "v1" "kind" "ConfigMap" "metadata" (include "cd-pipeline.meta" (dict "root" $r "name" $cm "ns" $name "wave" $w.config) | fromYaml) "data" (dict "verify-e2e-operation.sh" ($r.Files.Get "files/verify-e2e-operation.sh"))) -}}
{{- $env := list (dict "name" "APP" "value" $app) (dict "name" "EXPECTED" "value" (printf "%s%s" $prefix "{{args.chart-version}}")) (dict "name" "WAIT_SECONDS" "value" (toString (int $pv.waitSeconds))) (dict "name" "POLL_SECONDS" "value" (toString (int $pv.pollSeconds))) (dict "name" "JQ" "value" "/opt/jq/jq") -}}
{{- if ne $ns "argocd" -}}{{- $env = append $env (dict "name" "ARGOCD_NAMESPACE" "value" $ns) -}}{{- end -}}
{{- $mounts := list (dict "name" "script" "mountPath" "/scripts" "readOnly" true) (dict "name" "jq-tool" "mountPath" "/opt/jq" "readOnly" true) -}}
{{- $vols := list (include "cd-pipeline.scriptVolume" (dict "configMap" $cm) | fromYaml) (dict "name" "jq-tool" "image" (dict "reference" (required "cd-pipeline: promotedVersion.jqImage is required" $pv.jqImage) "pullPolicy" "IfNotPresent")) -}}
{{- include "cd-pipeline.jobCheck" (dict "root" $r "name" $at "ns" $name "metric" "e2e-operation" "args" (list "chart-version") "sa" $sa "image" (required "cd-pipeline: promotedVersion.image is required" $pv.image) "command" (list "/bin/sh" "/scripts/verify-e2e-operation.sh") "env" $env "mounts" $mounts "volumes" $vols "deadline" (add (int $pv.waitSeconds) $v.jobs.headroomSeconds)) -}}
{{- end -}}

{{- /* The metrics gate (verification.metricsGate), then the Job checks of the project's own. */ -}}
{{- $checks := $verif.checks | default list -}}
{{- if $verif.metricsGate -}}
{{- /* With metricsGate.objects false the Stage only names the gate: its
       ServiceAccount, ConfigMap and AnalysisTemplate are rendered by
       whoever owns the cluster the gate runs on, under the same names, as
       the promoted-version check's are. */ -}}
{{- if eq (toString $v.metricsGate.objects) "false" -}}
{{- $templates = append $templates (printf "%s-%s-metrics-gate" $slug $s.name) -}}
{{- else -}}
{{- $checks = prepend $checks (include "cd-pipeline.metricsGateCheck" (dict "root" $r "p" $p "s" $s "slug" $slug) | fromYaml) -}}
{{- end -}}
{{- end -}}
{{- range $c := $checks -}}
{{- $templates = append $templates $c.name -}}
{{- if hasKey $c "serviceAccount" -}}
{{- if (hasKey $c "createServiceAccount" | ternary $c.createServiceAccount true) -}}
{{- include "cd-pipeline.doc" (dict "apiVersion" "v1" "kind" "ServiceAccount" "metadata" (include "cd-pipeline.meta" (dict "root" $r "name" $c.serviceAccount "ns" $name "wave" $w.config) | fromYaml)) -}}
{{- end -}}
{{- end -}}
{{- $mounts := list -}}
{{- $vols := list -}}
{{- $command := $c.command -}}
{{- if $c.script -}}
{{- $file := $c.script.file | default "verify.sh" -}}
{{- include "cd-pipeline.doc" (dict "apiVersion" "v1" "kind" "ConfigMap" "metadata" (include "cd-pipeline.meta" (dict "root" $r "name" $c.script.configMap "ns" $name "wave" $w.config) | fromYaml) "data" (dict $file $c.script.content)) -}}
{{- $mounts = append $mounts (dict "name" "script" "mountPath" "/scripts" "readOnly" true) -}}
{{- $vols = append $vols (include "cd-pipeline.scriptVolume" (dict "configMap" $c.script.configMap) | fromYaml) -}}
{{- if not $command -}}{{- $command = list "/bin/sh" (printf "/scripts/%s" $file) -}}{{- end -}}
{{- end -}}
{{- $mounts = concat $mounts ($c.volumeMounts | default list) -}}
{{- $vols = concat $vols ($c.volumes | default list) -}}
{{- include "cd-pipeline.jobCheck" (dict "root" $r "name" $c.name "ns" $name "metric" ($c.metric | default "check") "args" ($c.args | default (list "chart-version")) "sa" (required "cd-pipeline: a check needs a serviceAccount" $c.serviceAccount) "image" $c.image "command" (required "cd-pipeline: a check needs a command or a script" $command) "env" $c.env "mounts" $mounts "volumes" $vols "deadline" $c.deadlineSeconds "ttl" $c.ttlSecondsAfterFinished) -}}
{{- end -}}
{{- $templates = concat $templates ($verif.analysisTemplates | default list) -}}

{{- /* The Stage. */ -}}
{{- $sources := ternary (dict "stages" (list $upstream)) (dict "direct" true) (ne $upstream "") -}}
{{- $spec := dict "requestedFreight" (list (dict "origin" (dict "kind" "Warehouse" "name" .whName) "sources" $sources)) -}}
{{- if $templates -}}
{{- $_ := set $spec "verification" (dict "analysisTemplates" (include "cd-pipeline.names" $templates | fromYamlArray) "args" $verArgs) -}}
{{- end -}}
{{- if $s.promotionTemplate -}}
{{- $_ := set $spec "promotionTemplate" $s.promotionTemplate -}}
{{- else -}}
{{- $_ := set $spec "promotionTemplate" (dict "spec" (include "cd-pipeline.promotion" (dict "root" $r "p" $p "s" $s "stages" .stages "slug" $slug "eff" .eff) | fromYaml)) -}}
{{- end -}}
{{- include "cd-pipeline.doc" (dict "apiVersion" "kargo.akuity.io/v1alpha1" "kind" "Stage" "metadata" (include "cd-pipeline.meta" (dict "root" $r "name" $s.name "ns" $name "wave" $w.stage) | fromYaml) "spec" $spec) -}}
{{- end -}}

{{/*
One Warehouse subscription to a chart map (`chart`, a source's or a
companion's): a chart subscription, or an image one with subscribeAs image.
As YAML for `fromYaml`. Call with (dict "name" <project> "chart" .. "where" <key path for messages>).
*/}}
{{- define "cd-pipeline.subscription" -}}
{{- $name := .name -}}
{{- $chart := .chart | default dict -}}
{{- $sub := dict "repoURL" (required (printf "cd-pipeline: projects.%s.%s.repoURL is required (or warehouse.subscriptions)" $name .where) $chart.repoURL) "semverConstraint" (required (printf "cd-pipeline: projects.%s.%s.semver is required" $name .where) $chart.semver) "discoveryLimit" ($chart.discoveryLimit | default 20) -}}
{{- if $chart.name -}}{{- $_ := set $sub "name" $chart.name -}}{{- end -}}
{{- $mode := include "cd-pipeline.chartMode" (dict "name" $name "chart" $chart) | fromYaml -}}
{{- if $mode.image -}}
{{- /* An OCI chart whose tags carry a `v`: Helm's tag listing drops them, so subscribe as an image. */ -}}
{{- $sub = dict "repoURL" $mode.repo "imageSelectionStrategy" "SemVer" "strictSemvers" $mode.strict "constraint" $chart.semver "discoveryLimit" ($chart.discoveryLimit | default 20) -}}
{{- toYaml (dict "image" $sub) -}}
{{- else -}}
{{- toYaml (dict "chart" $sub) -}}
{{- end -}}
{{- end -}}

{{/*
A project's companions (`companions`), checked: each one's repository is
neither the chart's nor another companion's (the promotion reads each
artifact of the Freight by its repository), and no Stage spells its own
promotionTemplate (it would not write the companions' pins). Call with the
project map.
*/}}
{{- define "cd-pipeline.checkCompanions" -}}
{{- $p := . -}}
{{- if $p.companions -}}
{{- $seen := dict (include "cd-pipeline.chartMode" (dict "name" $p.name "chart" ($p.chart | default dict)) | fromYaml).repo "chart" -}}
{{- range $cn := keys $p.companions | sortAlpha -}}
{{- $repo := (include "cd-pipeline.chartMode" (dict "name" $p.name "chart" (index $p.companions $cn)) | fromYaml).repo -}}
{{- if hasKey $seen $repo -}}{{- fail (printf "cd-pipeline: projects.%s.companions.%s: repository %s is also %s's; each artifact of the Freight is read by its repository" $p.name $cn $repo (index $seen $repo)) -}}{{- end -}}
{{- $_ := set $seen $repo (printf "companions.%s" $cn) -}}
{{- end -}}
{{- range $s := ($p.stages | default list) -}}
{{- if $s.promotionTemplate -}}{{- fail (printf "cd-pipeline: projects.%s.stages.%s.promotionTemplate is spelled out, so it would not write the pins of companions" $p.name $s.name) -}}{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "cd-pipeline.names" -}}
{{- $out := list -}}
{{- range $n := . -}}{{- $out = append $out (dict "name" $n) -}}{{- end -}}
{{- toYaml $out -}}
{{- end -}}

{{/*
A project's companions as one source's Warehouse subscribes to them: each
companion with its `sources.<source>` laid over it (its repository and range
from that source), and without `sources`. With source "", the companions as
they are, without `sources`. As YAML for `fromYaml`.
Call with (dict "companions" <map> "source" <name or "">).
*/}}
{{- define "cd-pipeline.companionsFrom" -}}
{{- $out := dict -}}
{{- range $cn, $co := .companions -}}
{{- $c := omit $co "sources" -}}
{{- with $.source -}}{{- with index ($co.sources | default dict) . -}}{{- $c = merge (deepCopy .) $c -}}{{- end -}}{{- end -}}
{{- $_ := set $out $cn $c -}}
{{- end -}}
{{- toYaml $out -}}
{{- end -}}
