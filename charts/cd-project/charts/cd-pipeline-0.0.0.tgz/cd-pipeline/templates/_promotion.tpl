{{/*
A Stage's promotion: write the promoted pin to the repository's values file,
by pull request on every hop after the project's first Stage and straight to
the branch on the first. As YAML for `fromYaml`: the promotion template's spec.
Call with (dict "root" . "p" <project> "s" <stage> "stages" <name -> stage> "slug" .. "eff" <cd-pipeline.effective>).
*/}}
{{- define "cd-pipeline.promotion" -}}
{{- $r := .root -}}
{{- $v := $r.Values -}}
{{- $pr := .eff.promotion -}}
{{- $p := .p -}}
{{- $s := .s -}}
{{- $chart := $p.chart | default dict -}}
{{- $chartName := $chart.name | default "" -}}
{{- $prefix := $chart.versionPrefix | default "" -}}
{{- $repo := required (printf "cd-pipeline: projects.%s: git.repoURL is required (the release's git.repoURL, or the project's own)" $p.name) .eff.git.repoURL -}}
{{- $upstream := $s.from | default "" -}}
{{- $mode := $s.mode | default (ternary "pr" "direct" (ne $upstream "")) -}}
{{- $retry := dict "errorThreshold" $pr.retry.errorThreshold "timeout" $pr.retry.timeout -}}
{{- /* A Stage of a customer's chain fills `{stage}` with its Stage of
       stageOrder (the cluster) and `{customer}` with its customer. */ -}}
{{- $own := dict "stage" ($s.env | default $s.name) "pinKey" ($p.pinKey | default "") -}}
{{- with $s.customer -}}{{- $_ := set $own "customer" . -}}{{- end -}}
{{- $tokens := merge $own (include "cd-pipeline.projectTokens" $p | fromYaml) -}}
{{- range $k := list "pinFile" "pinKey" "commitMessage" "prTitle" -}}
{{- include "cd-pipeline.checkTokens" (dict "p" $p "where" (printf "promotion.%s" $k) "s" (index $pr $k)) -}}
{{- end -}}
{{- $chm := include "cd-pipeline.chartMode" (dict "name" $p.name "chart" $chart) | fromYaml -}}
{{- $from := include "cd-pipeline.chartFrom" (dict "name" $chartName "vars" true "image" $chm.image) -}}
{{- $version := printf "${{ %s.%s }}" $from (ternary (ternary "Digest" "Tag" $chm.digest) "Version" $chm.image) -}}
{{- /* A digest pin also offers the discovered tag, for the wording of the commit and the pull request. */ -}}
{{- $wording := deepCopy $tokens -}}
{{- if $chm.digest -}}{{- $_ := set $wording "tag" (printf "${{ %s.Tag }}" $from) -}}{{- end -}}
{{- $steps := list -}}

{{- /* The gate: before a hop moves a pin, the Applications that the version it
       promotes from already runs in must be Healthy and Synced. The first Stage
       has none, and no Stage waits on the Applications it is about to update. */ -}}
{{- if $upstream -}}
{{- $apps := list -}}
{{- range $a := (get $.stages $upstream).applications -}}
{{- $apps = append $apps (dict "name" $a "namespace" $v.argocd.namespace "waitFor" (list "health" "sync" "operation")) -}}
{{- end -}}
{{- if $apps -}}
{{- $steps = append $steps (dict "uses" "argocd-wait" "as" "gate" "retry" (dict "timeout" $pr.gate.timeout) "config" (dict "apps" $apps)) -}}
{{- end -}}
{{- end -}}

{{- $steps = append $steps (dict "uses" "git-clone" "retry" $retry "config" (dict "repoURL" "${{ vars.gitRepo }}" "checkout" (list (dict "branch" $pr.branch "path" "./repo")))) -}}
{{- $pinKey := include "cd-pipeline.fill" (dict "s" $pr.pinKey "tokens" $tokens) -}}
{{- $updates := list (dict "key" $pinKey "value" (printf "%s%s" $prefix $version)) -}}
{{- /* One pin per companion, in the same file and commit: the artifact of the
       same Freight, read by its repository. */ -}}
{{- range $cn := keys ($p.companions | default dict) | sortAlpha -}}
{{- $co := index $p.companions $cn -}}
{{- $key := printf "%s-%s" $pinKey $cn -}}
{{- with $co.pinKey -}}
{{- include "cd-pipeline.checkTokens" (dict "p" $p "where" (printf "companions.%s.pinKey" $cn) "s" .) -}}
{{- $key = include "cd-pipeline.fill" (dict "s" . "tokens" $tokens) -}}
{{- end -}}
{{- $cm := include "cd-pipeline.chartMode" (dict "name" $p.name "chart" $co) | fromYaml -}}
{{- $cfrom := include "cd-pipeline.chartFrom" (dict "repoURL" $cm.repo "name" ($co.name | default "") "vars" false "image" $cm.image) -}}
{{- $updates = append $updates (dict "key" $key "value" (printf "%s${{ %s.%s }}" ($co.versionPrefix | default "") $cfrom (ternary (ternary "Digest" "Tag" $cm.digest) "Version" $cm.image))) -}}
{{- end -}}
{{- $steps = append $steps (dict "uses" "yaml-update" "config" (dict "path" (printf "./repo/%s" (include "cd-pipeline.fill" (dict "s" $pr.pinFile "tokens" $tokens))) "updates" $updates)) -}}
{{- $steps = append $steps (dict "uses" "git-commit" "as" "commit" "retry" $retry "config" (dict "path" "./repo" "message" (include "cd-pipeline.fill" (dict "s" $pr.commitMessage "tokens" (merge (dict "version" $version) $wording))))) -}}
{{- if eq $mode "pr" -}}
{{- $committed := "${{ status('commit') == 'Succeeded' }}" -}}
{{- $steps = append $steps (dict "uses" "git-push" "as" "push" "if" $committed "retry" $retry "config" (dict "path" "./repo" "generateTargetBranch" true)) -}}
{{- $openPR := dict "repoURL" "${{ vars.gitRepo }}" "provider" $pr.provider "sourceBranch" "${{ outputs.push.branch }}" "targetBranch" $pr.branch "title" (include "cd-pipeline.fill" (dict "s" $pr.prTitle "tokens" $wording)) -}}
{{- if $pr.prLabels -}}{{- $_ := set $openPR "labels" $pr.prLabels -}}{{- end -}}
{{- $steps = append $steps (dict "uses" "git-open-pr" "as" "open-pr" "if" $committed "retry" $retry "config" $openPR) -}}
{{- /* No timeout on the wait: it waits on a person merging, which is not bounded by the transient-failure budget. */ -}}
{{- $steps = append $steps (dict "uses" "git-wait-for-pr" "if" $committed "retry" (dict "errorThreshold" $pr.retry.errorThreshold) "config" (dict "repoURL" "${{ vars.gitRepo }}" "provider" $pr.provider "prNumber" "${{ outputs['open-pr'].pr.id }}")) -}}
{{- else -}}
{{- $steps = append $steps (dict "uses" "git-push" "retry" $retry "config" (dict "path" "./repo" "targetBranch" $pr.branch)) -}}
{{- end -}}
{{- /* The end-to-end run: a Stage that names its end-to-end Application syncs it
       last, once the pin is in the repository. The Application's hook runs the
       suite, and the step waits for the operation, so the timeout covers the
       suite and the rollout it waits for. The Application must authorize this
       Stage; it is not in `applications`, so no later Stage waits on it. */ -}}
{{- if $s.e2eApplication -}}
{{- $steps = append $steps (dict "uses" "argocd-update" "as" "e2e" "retry" (dict "timeout" "25m0s") "config" (dict "apps" (list (dict "name" $s.e2eApplication "namespace" $v.argocd.namespace)))) -}}
{{- end -}}
{{- $vars := list (dict "name" "gitRepo" "value" $repo) (dict "name" "chartRepo" "value" $chm.repo) (dict "name" "chartName" "value" $chartName) -}}
{{- toYaml (dict "vars" $vars "steps" $steps) -}}
{{- end -}}
